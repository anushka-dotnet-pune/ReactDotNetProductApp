import React, { useEffect, useState } from "react";
import { fetchProducts } from "../api/booksApi";
import Spinner from "../components/Spinner";
import ErrorAlert from "../components/ErrorAlert";
import BookList from "../components/BookList";

const HomePage = () => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [products, setProducts] = useState([]);

  useEffect(() => {
    fetchProducts()
      .then(data => {
        setProducts(data);
        setLoading(false);
      })
      .catch(err => {
        setError(err.message);
        setLoading(false);
      });
  }, []);

  return (
    <div>
      <h1 style={{ textAlign: "center" }}>API Products</h1>

      {loading && <Spinner />}
      {error && <ErrorAlert message={error} />}
      {!loading && !error && <BookList products={products} />}
    </div>
  );
};

export default HomePage;
