const API_URL = "https://localhost:7078/api/products"; 
// replace with your actual .NET API endpoint

export const fetchProducts = async () => {
  const response = await fetch(API_URL);

  if (!response.ok) {
    throw new Error("Failed to fetch data from API");
  }

  return response.json();
};
