import React from "react";

const ErrorAlert = ({ message }) => {
  return (
    <div
      style={{
        padding: "10px",
        backgroundColor: "#ffcccc",
        color: "red",
        borderRadius: "5px",
        margin: "10px auto",
        width: "80%",
        textAlign: "center",
      }}
    >
      <strong>Error:</strong> {message}
    </div>
  );
};

export default ErrorAlert;
