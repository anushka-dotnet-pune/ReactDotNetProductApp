import React from "react";

const Spinner = () => {
  return (
    <div style={{ textAlign: "center", marginTop: "20px" }}>
      <h3>Loading...</h3>
    </div>
  );
};

export default Spinner;
