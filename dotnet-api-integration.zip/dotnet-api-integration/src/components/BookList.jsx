import React from "react";

const BookList = ({ products }) => {
  return (
    <div style={{ padding: "20px" }}>
      <h2>Products List</h2>

      {products.map((item) => (
        <div
          key={item.id}
          style={{
            border: "1px solid #ccc",
            padding: "15px",
            borderRadius: "10px",
            marginBottom: "10px",
          }}
        >
          <h3>{item.name}</h3>
          <p>{item.description}</p>
          <p><strong>Price:</strong> ₹{item.price}</p>
          <p><strong>Quantity:</strong> {item.quantity}</p>
        </div>
      ))}
    </div>
  );
};

export default BookList;
